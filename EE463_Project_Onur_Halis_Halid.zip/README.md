# EE463_Project_Onur_Halis_Halid

Google Docs Link:
https://docs.google.com/document/d/1aUbiogccKc2OzVAZYlh6jZ1xVPGB8dJCKc63r1MVhF4/edit?usp=sharing

Google Slides Link:
https://docs.google.com/presentation/d/1uwI3XgHL8aJ05a1YgI6h8vrzoWMBWJBdzZAcA0tdUn0/edit?usp=sharing
